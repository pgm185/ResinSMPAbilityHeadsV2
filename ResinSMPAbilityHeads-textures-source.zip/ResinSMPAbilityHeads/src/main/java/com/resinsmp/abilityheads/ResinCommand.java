package com.resinsmp.abilityheads;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

public final class ResinCommand implements CommandExecutor, TabCompleter {
    private final ResinSMPAbilityHeads plugin;

    public ResinCommand(ResinSMPAbilityHeads plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("resinheads.admin")) {
            sender.sendMessage(plugin.message("no-permission"));
            return true;
        }

        if (command.getName().equalsIgnoreCase("giveallheads")) {
            Player target;
            if (args.length > 0) target = Bukkit.getPlayerExact(args[0]);
            else target = sender instanceof Player p ? p : null;
            if (target == null) {
                sender.sendMessage(plugin.message(sender instanceof Player ? "player-not-found" : "usage"));
                return true;
            }
            giveAll(target);
            sender.sendMessage(plugin.message("given-all", "player", target.getName()));
            return true;
        }

        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "reload" -> {
                plugin.reloadAllFiles();
                sender.sendMessage(plugin.message("reloaded"));
            }
            case "list" -> sendHeadList(sender);
            case "give" -> {
                if (args.length < 3) {
                    sender.sendMessage(HeadItems.color("&eUsage: /resinheads give <player> <head>"));
                    return true;
                }
                Player target = Bukkit.getPlayerExact(args[1]);
                HeadType head = HeadType.byId(args[2]).orElse(null);
                if (target == null) sender.sendMessage(plugin.message("player-not-found"));
                else if (head == null) sender.sendMessage(plugin.message("unknown-head"));
                else {
                    give(target, head);
                    sender.sendMessage(plugin.message("given-one", "head", head.displayName()).replace("%player%", target.getName()));
                }
            }
            case "giveall" -> {
                if (args.length < 2) {
                    sender.sendMessage(HeadItems.color("&eUsage: /resinheads giveall <player>"));
                    return true;
                }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) sender.sendMessage(plugin.message("player-not-found"));
                else {
                    giveAll(target);
                    sender.sendMessage(plugin.message("given-all", "player", target.getName()));
                }
            }
            default -> sendHelp(sender);
        }
        return true;
    }

    private void give(Player target, HeadType type) {
        ItemStack item = plugin.headItems().create(type);
        var leftovers = target.getInventory().addItem(item);
        leftovers.values().forEach(stack -> target.getWorld().dropItemNaturally(target.getLocation(), stack));
        if (!leftovers.isEmpty()) target.sendMessage(plugin.message("full-inventory"));
    }

    private void giveAll(Player target) {
        boolean overflow = false;
        for (HeadType type : HeadType.values()) {
            var leftovers = target.getInventory().addItem(plugin.headItems().create(type));
            if (!leftovers.isEmpty()) {
                overflow = true;
                leftovers.values().forEach(stack -> target.getWorld().dropItemNaturally(target.getLocation(), stack));
            }
        }
        if (overflow) target.sendMessage(plugin.message("full-inventory"));
    }

    private void sendHeadList(CommandSender sender) {
        sender.sendMessage(HeadItems.color("&b&lRESIN SMP &8- &f35 Ability Heads"));
        for (HeadType head : HeadType.values()) {
            String color = switch (head.rarity()) {
                case "RARE" -> "&9";
                case "EPIC" -> "&5";
                case "LEGENDARY" -> "&6";
                default -> "&a";
            };
            sender.sendMessage(HeadItems.color(color + head.displayName() + " &8- &7" + head.abilityName()));
        }
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(HeadItems.color("&b&lRESIN SMP Ability Heads"));
        sender.sendMessage(HeadItems.color("&f/giveallheads [player] &7- Give all 35 heads"));
        sender.sendMessage(HeadItems.color("&f/resinheads give <player> <head> &7- Give one head"));
        sender.sendMessage(HeadItems.color("&f/resinheads giveall <player> &7- Give all heads"));
        sender.sendMessage(HeadItems.color("&f/resinheads list &7- List all heads"));
        sender.sendMessage(HeadItems.color("&f/resinheads reload &7- Reload YAML configs"));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("resinheads.admin")) return List.of();
        if (args.length == 1) return startsWith(List.of("give", "giveall", "reload", "list", "help"), args[0]);
        if (args.length == 2 && (args[0].equalsIgnoreCase("give") || args[0].equalsIgnoreCase("giveall"))) {
            return startsWith(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(), args[1]);
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
            return startsWith(java.util.Arrays.stream(HeadType.values()).map(HeadType::id).toList(), args[2]);
        }
        return List.of();
    }

    private List<String> startsWith(List<String> choices, String prefix) {
        String needle = prefix.toLowerCase(Locale.ROOT);
        return choices.stream().filter(s -> s.toLowerCase(Locale.ROOT).startsWith(needle)).collect(Collectors.toCollection(ArrayList::new));
    }
}
