# ResinSMPAbilityHeads

Custom Paper plugin source project for RESIN SMP. It defines **35 ability heads** across Common, Rare, Epic and Legendary rarities, with passive helmet effects, active abilities, cooldowns, configurable mob-drop percentages, persistent item IDs, admin commands and automatically-created YAML configuration.

## Target server

- Minecraft Java Edition: **26.2**
- Server software: **Paper 26.2**
- Paper API compile dependency: `26.2.build.135-stable`
- Required Java runtime/toolchain: **Java 25**

Paper 26.2 has a published stable API. Paper 26.x requires Java 25; Java 21 is not sufficient. Set the hosting panel's server Java runtime to Java 25.

## Easiest build option: GitHub Actions (works from a phone)

This project includes `.github/workflows/build.yml`. GitHub Actions can install Java 25 and Gradle, compile the plugin, and attach the resulting JAR as a downloadable workflow artifact. This still requires the project to be uploaded to a GitHub repository and a successful build; no JAR is included in this source ZIP.

1. On GitHub, create a new repository named `ResinSMPAbilityHeads`.
2. Extract this ZIP, then upload the **contents** of the `ResinSMPAbilityHeads` folder to the repository root. Keep the `.github/workflows/build.yml` file and the `src`, `build.gradle.kts`, `settings.gradle.kts`, and `gradle.properties` paths intact.
3. Commit the files to the `main` branch. The build workflow should start automatically.
4. Open the repository's **Actions** tab, choose **Build ResinSMPAbilityHeads**, and open the newest run.
5. If the run is green, scroll to **Artifacts** and download `ResinSMPAbilityHeads-1.0.0`. Extract that artifact ZIP to get `ResinSMPAbilityHeads-1.0.0.jar`.
6. If the run is red, open the run and read the first compiler/dependency error; do not upload any file from a failed build to the server.

GitHub Actions uses a hosted build machine, so this avoids needing Java 25 or Gradle installed on your phone.

## Build the plugin JAR

This source project needs a computer or build service with JDK 25, Gradle 9.x and internet access to resolve the Paper API dependency.

From this folder run:

```bash
gradle clean build
```

The output is:

```text
build/libs/ResinSMPAbilityHeads-1.0.0.jar
```

The Paper API is a `compileOnly` dependency and is not packed into the plugin JAR.

## Install on Skillora / Paper

1. Confirm the server software is **Paper 26.2** and its startup Java runtime is **25**.
2. Stop the server and take a full world backup.
3. Upload `ResinSMPAbilityHeads-1.0.0.jar` into the server's `plugins/` folder.
4. Start the server and check the console for `ResinSMPAbilityHeads enabled`.
5. The plugin creates its data folder and default files on first successful enable.
6. Run `/resinheads reload` after editing YAML files.

Generated files:

```text
plugins/ResinSMPAbilityHeads/
  config.yml
  abilities.yml
  drops.yml
  messages.yml
  textures.yml
```

All five YAML files are copied from the plugin on first successful enable. Allay recall markers are session-only and clear when a player disconnects or the server restarts.

## Admin commands

All commands require `resinheads.admin` (OP by default).

| Command | Description |
|---|---|
| `/giveallheads` | Gives all 35 heads to yourself |
| `/giveallheads <player>` | Gives all 35 heads to an online player |
| `/resinheads give <player> <head>` | Gives one named head |
| `/resinheads giveall <player>` | Gives all 35 heads to a player |
| `/resinheads list` | Lists the 35 IDs and ability names |
| `/resinheads reload` | Reloads config, abilities, drops, messages and head textures |
| `/resinheads help` | Shows command help |

If the target inventory is full, remaining heads are dropped beside that player.

## Head ability controls

Wear a custom head in the helmet slot. For standard active abilities, hold an empty hand and right-click in the air. This avoids hijacking chests, doors and block interactions.

- **Slime Head:** while sneaking, right-click in the air grows and left-click in the air shrinks. Each size change has a configurable 3-second cooldown. Scale is clamped by `config.yml`; the original scale is restored on unequip, quit or clean plugin shutdown.
- **Allay Head:** sneak + right-click marks your current safe location; normal right-click returns to it. Recall only works in the same world by default and only when the saved spot has a solid floor and two passable blocks. The mark lasts for the current online session.
- **Bat Head:** Night Vision X (amplifier 9) is refreshed while worn; right-click activates a short Echo Sense pulse.

Other heads have their own active ability and/or passive effect, controlled separately in `abilities.yml`. Cooldowns are configurable in seconds.

## Drop rules

- A head only drops from its matching mob type.
- `drops.yml` controls each head's percentage chance and enable/disable switch.
- `config.yml` can require player kills and block mobs marked as spawned by spawners, spawn eggs, dispensers, trial spawners or ominous item spawners. The origin marker is stored on the entity, so it survives chunk save/reload.
- The 100% values are a guaranteed roll from that mob's eligible death, not a vanilla drop mechanic.

## Custom visuals

Each head has a unique persistent ID, display name, rarity, lore and ability. Six heads use their matching vanilla skull textures (Zombie, Skeleton, Creeper, Wither Skeleton, Ender Dragon and Piglin Brute). The other 29 use distinct named Minecraft profile textures configured in `textures.yml`; no separate resource pack or extra plugin is required. Minecraft resolves these profile names through its profile/skin services, so players need an internet connection and the first texture load may take a moment. The selected profiles are classic MHF/community head accounts, so a few are representative fantasy/mob-style skins rather than exact modern mob models. Profile-name references were selected from public MHF head lists (Minecraft Wiki and MC-Craft). You can replace any profile name in `textures.yml` with another valid Minecraft username and then run `/resinheads reload`.

## Testing status and limitations

This project was authored against the Paper 26.2 API documentation and checked for configuration/command consistency. All bundled YAML files were checked for valid syntax, all 35 head IDs are present, and all 29 player-head IDs have distinct profile-name mappings. The current build environment only has Java 21, no Gradle installation, and no network access to retrieve JDK 25 or the Paper API artifact. Therefore **a real Paper-linked compile and live-server test could not be run here**, and no compiled JAR is included. Do not upload this source ZIP as if it were a plugin JAR. Build it with JDK 25 + Gradle 9.x first, then test it on a separate copy of the server before the live SMP.

Player scale is handled through Paper's `Attribute.SCALE`, which exists in the 26.2 API. Exact collision feel still needs in-game testing, especially at the configured size limits. Area abilities have a target cap to reduce server load.
